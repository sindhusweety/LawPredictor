#undef HAVE_INLINE
#ifndef NO_INLINE
#define NO_INLINE
#endif
#define DESC " (static)"
#include "test.c"
